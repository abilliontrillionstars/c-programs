// second program. prints the same information, but without any #include statements.

// Name: Ethan Ward
// Class: Systems Programming   Section: ETEC 2110-51
// Assignment: Lab 1, part 3

int printf (const char *__format, ...);

main()
{
    printf("Name: Ethan Ward\nQuote: 'You are not the exception to recovery.'\n -Johnny Montilla \n");
}
