// Name: Ethan Ward
// Class: Systems Programming   Section: ETEC 2110-51
// Assignment: Lab 1, part 1

//first C program! prints your name and favorite quote.
#include <stdio.h>

main()
{
    printf("Name: Ethan Ward\nQuote: 'You are not the exception to recovery'\n -Johnny Montilla \n");
}
